package in.application.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.application.dto.Student;
import in.application.service.IStudentService;
import in.application.servicefactory.StudentServiceFactory;

//In real  time there will be only one Servlet which will deal with multiple logics.
//Also as per MVC design there should be only one Servlet.
//We don't know if the type of request will be GET or POST, hence keeping both the methods.

@WebServlet("/controller/*")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doProcess(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doProcess(request, response);
	}

	private void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		IStudentService stdService = StudentServiceFactory.getStudentService();

		System.out.println("Request URI: " + request.getRequestURI());
		System.out.println("Path Info: " + request.getPathInfo());

		if (request.getRequestURI().endsWith("addform")) {
			String sid = request.getParameter("sid");
			String sage = request.getParameter("sage");
			String sname = request.getParameter("sname");
			String saddr = request.getParameter("saddr");

			Student student = new Student();
			student.setSid(Integer.parseInt(sid));
			student.setSname(sname);
			student.setSage(Integer.parseInt(sage));
			student.setSaddress(saddr);

			String status = stdService.addStudent(student);
			PrintWriter out = response.getWriter();
			if (status.equalsIgnoreCase("success")) {
				out.println("<h1 style='color:green; text-align:center;'>REGISTRATION SUCCESS</h1>");
			} else {
				out.println("<h1 style='color:red; text-align:center;'>REGISTRATION FAILED</h1>");

			}
			out.close();

		}

		if (request.getRequestURI().endsWith("searchform")) {
			String sid = request.getParameter("sid");
			Student student = stdService.searchStudent(Integer.parseInt(sid));
			PrintWriter out = response.getWriter();
			if (student != null) {

				out.println("<body>");
				out.println("<center>");
				out.println("<h1 style='color:green';>Student details for ID: " + sid + "</h1>");
				out.println("</br>");
				out.println("<table border='1'>");
				out.println("<tr><th>ID</th><td>" + student.getSid() + "</td></tr>");
				out.println("<tr><th>NAME</th><td>" + student.getSname() + "</td></tr>");
				out.println("<tr><th>AGE</th><td>" + student.getSage() + "</td></tr>");
				out.println("<tr><th>ADDRESS</th><td>" + student.getSaddress() + "</td></tr>");
				out.println("</table>");
				out.println("</center>");
				out.println("</body>");
			} else {
				out.println("<h1 style='color:red; text-align:center;'>RECORD NOT AVAILABLE FOR ENTERED ID: " + sid
						+ "</h1>");
			}
			out.close();
		}

		if (request.getRequestURI().endsWith("deleteform")) {
			String sid = request.getParameter("sid");
			String status = stdService.deleteStudent(Integer.parseInt(sid));

			PrintWriter out = response.getWriter();
			if (status.equalsIgnoreCase("success")) {
				out.println("<body>");
				out.println("<h1 style='color:green;text-align:center'>RECORD WITH ID '" + sid + "' IS DELETED</h1>");
				out.println("</body>");
			} else if (status.equalsIgnoreCase("failure")) {
				out.println("<body>");
				out.println("<h1 style='color:red;text-align:center'>RECORD DELETION FAILED</h1>");
				out.println("</body>");
			} else {
				out.println("<body>");
				out.println("<h1 style='color:red;text-align:center'>RECORD WITH ID '" + sid
						+ "' IS NOT AVAILABLE FOR DELETION</h1>");
				out.println("</body>");
			}
			out.close();
		}

		if (request.getRequestURI().endsWith("editform")) {
			String sid = request.getParameter("sid");
			PrintWriter out = response.getWriter();

			Student student = stdService.searchStudent(Integer.parseInt(sid));
			if (student != null) {
				// display student records as a form data so it is editable
				out.println("<body>");
				out.println("<center>");
				out.println("<form method='post' action='./controller/updaterecord'>");
				out.println("<table>");
				out.println("<tr><th>ID</th><td>" + student.getSid() + "</td></tr>");
				out.println("<input type='hidden' name ='sid' value='"+student.getSid()+"'/>");
				out.println("<tr><th>NAME</th><td><input type='text' name='sname' value='" + student.getSname()
						+ "'/></td></tr>");
				out.println("<tr><th>AGE</th><td><input type='text' name='sage' value='" + student.getSage()
						+ "'/></td></tr>");
				out.println("<tr><th>ADDRESS</th><td><input type='text' name='saddress' value='" + student.getSaddress()
						+ "'/></td></tr>");
				out.println("<tr><td></td><td><input type='submit' value='update'></td></tr>");

				out.println("</center>");
				out.println("</body>");

			} else {
				out.println("<body>");
				out.println("<h1 style='color:red;text-align:center'>RECORD WITH ID '" + sid
						+ "' IS NOT AVAILABLE FOR UPDATION</h1>");
				out.println("</body>");

			}
			out.close();
		}
		if(request.getRequestURI().endsWith("updaterecord")) {
			PrintWriter out = response.getWriter();

			String sid = request.getParameter("sid");
			String sname = request.getParameter("sname");
			String sage = request.getParameter("sage");
			String saddress = request.getParameter("saddress");
			
			Student student = new Student();
			student.setSid(Integer.parseInt(sid));
			student.setSname(sname);
			student.setSage(Integer.parseInt(sage));
			student.setSaddress(saddress);
			
			String status = stdService.updateStudent(student);
			if(status.equalsIgnoreCase("success")) {
				out.println("<h1 style='color:green;text-align:center';>DETAILS UPDATED FOR RECORD WITH ID"+sid+"</h1>");
			}else {
				out.println("<h1 style='color:red;text-align:center'>RECORD UPDATION FAILED</h1>");
			}
		out.close();	
		}

	}
}
